library verilog;
use verilog.vl_types.all;
entity Neander_vlg_sample_tst is
    port(
        BUTTON0         : in     vl_logic;
        clk_50          : in     vl_logic;
        run_debug       : in     vl_logic;
        step            : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end Neander_vlg_sample_tst;
