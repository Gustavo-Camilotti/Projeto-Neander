module run_step_mode(
    input  wire clk_div,
    input  wire run_mode,
    input  wire step,
    output wire clk_out
);

    assign clk_out =
        run_mode ? clk_div : step;

endmodule
