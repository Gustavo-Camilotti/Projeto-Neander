module unidade_controle(
    //sinais de temporização
    input wire t0, t1, t2, t3, t4, t5, t6, t7,
    
    //instruções vindas do decodificador
    input wire NOP,
    input wire STA,
    input wire LDA,
    input wire ADD,
    input wire OR_inst,
    input wire AND_inst,
    input wire NOT_inst,
    input wire JMP,
    input wire JN,
    input wire JZ,
    input wire HLT,
    
    //flags de estado vindas dos flip-flops NZ
    input wire N_out,
    input wire Z_out,
    
    //sinais de controle de saida
    output wire cargaREM,
    output wire incrementaPC,
    output wire cargaRI,
    output wire sel,
    output wire cargaRDM,
    output wire Read,
    output wire Write,
    output wire ULA_Y,
    output wire ULA_ADD,
    output wire ULA_OR,
    output wire ULA_AND,
    output wire ULA_NOT,
    output wire cargaAC,
    output wire cargaNZ,
    output wire cargaPC,
    output wire goto_t0
);

    //logica Combinacional para as Expressões

    assign cargaREM = t0 + 
                       t3 * (STA + LDA + ADD + OR_inst + AND_inst + JMP + (JN * N_out) + (JZ * Z_out)) + 
                       t5 * (STA + LDA + ADD + OR_inst + AND_inst);

    assign incrementaPC = t1 + 
                         t4 * (STA + LDA + ADD + OR_inst + AND_inst) + 
                         t3 * ((JN * ~N_out) + (JZ * ~Z_out));

    assign cargaRI = t2;

    assign sel = t5 * (STA + LDA + ADD + OR_inst + AND_inst);

    assign cargaRDM = t6 * STA;

    assign Read = t1 + 
                  t4 * (STA + LDA + ADD + OR_inst + AND_inst + JMP + (JN * N_out) + (JZ * Z_out)) + 
                  t6 * (LDA + ADD + OR_inst + AND_inst);

    assign Write = t7 * STA;

    //sinais para o codificador_ula
    assign ULA_Y   = t7 * LDA;
    assign ULA_ADD = t7 * ADD;
    assign ULA_OR  = t7 * OR_inst;
    assign ULA_AND = t7 * AND_inst;
    assign ULA_NOT = t3 * NOT_inst;

    //carga de registradores de dados e flags
    assign cargaAC  = t7 * (LDA + ADD + OR_inst + AND_inst) + t3 * NOT_inst;
    assign cargaNZ  = cargaAC; 

    assign cargaPC  = t5 * (JMP + (JN * N_out) + (JZ * Z_out));

    //retorno para t0 com as condicionais e suas respectivas instruções
    assign goto_t0 = t7 * (STA + LDA + ADD + OR_inst + AND_inst) + 
                     t3 * (NOP + NOT_inst + (JN * ~N_out) + (JZ * ~Z_out)) + 
                     t5 * (JMP + (JN * N_out) + (JZ * Z_out));

endmodule
