// 1. Módulo do Flip-Flop D com Reset Assíncrono (Elemento básico de memória)
module ffd (
    input  wire clk,
    input  wire rst,
    input  wire d,
    output reg  q
);
    always @(posedge clk or posedge rst) begin
        if (rst) q <= 1'b0;
        else     q <= d;
    end
endmodule

// 2. Módulo Principal do Temporizador Estrutural
module temporizador (
    input  wire clk,
    input  wire rst,
    input  wire goto_t0,
    input  wire HLT,

    output wire t0,
    output wire t1,
    output wire t2,
    output wire t3,
    output wire t4,
    output wire t5,
    output wire t6,
    output wire t7
);

    // Fios internos para as saídas dos Flip-Flops (Estado Atual)
    wire q0, q1, q2;
    wire nq0, nq1, nq2;

    // Fios para a lógica de Próximo Estado (D2, D1, D0)
    wire d0, d1, d2;

    // Fios intermediários para a lógica do contador
    wire en, not_goto_t0;
    wire xor0, xor1, xor2;
    wire en1, en2;

    // --- FASE 1: Lógica de Controle ---
    // en = ~HLT (Se HLT for 1, 'en' vira 0 e a contagem pausa)
    not (en, HLT);                  
    // Inversor para zerar os Flip-Flops quando goto_t0 for acionado
    not (not_goto_t0, goto_t0);     

    // --- FASE 2: Lógica Combinacional do Próximo Estado (Contador) ---
    // Cálculo do D0
    xor (xor0, q0, en);
    and (d0, xor0, not_goto_t0);

    // Cálculo do D1
    and (en1, q0, en);
    xor (xor1, q1, en1);
    and (d1, xor1, not_goto_t0);

    // Cálculo do D2
    and (en2, q1, en1);
    xor (xor2, q2, en2);
    and (d2, xor2, not_goto_t0);

    // --- FASE 3: Instanciação dos Flip-Flops D ---
    // Criamos 3 componentes de memória e ligamos os fios
    ffd ff0 (.clk(clk), .rst(rst), .d(d0), .q(q0));
    ffd ff1 (.clk(clk), .rst(rst), .d(d1), .q(q1));
    ffd ff2 (.clk(clk), .rst(rst), .d(d2), .q(q2));

    // --- FASE 4: Decodificador de Saída (3 para 8) ---
    // Primeiro geramos os sinais invertidos do estado atual
    not (nq0, q0);
    not (nq1, q1);
    not (nq2, q2);

    // Portas AND acendendo a saída correta baseada no estado dos Flip-Flops
    and (t0, nq2, nq1, nq0); // Estado 000
    and (t1, nq2, nq1,  q0); // Estado 001
    and (t2, nq2,  q1, nq0); // Estado 010
    and (t3, nq2,  q1,  q0); // Estado 011
    and (t4,  q2, nq1, nq0); // Estado 100
    and (t5,  q2, nq1,  q0); // Estado 101
    and (t6,  q2,  q1, nq0); // Estado 110
    and (t7,  q2,  q1,  q0); // Estado 111

endmodule