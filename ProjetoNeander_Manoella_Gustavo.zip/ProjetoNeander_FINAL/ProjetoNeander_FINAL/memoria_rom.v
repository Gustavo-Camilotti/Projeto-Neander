module memoria_rom(
    input  wire [7:0] entrada, // Barramento de endereço (vem do REM)
    input  wire Read,          // Sinal de controle vindo da Unidade de Controle
    output reg  [7:0] saida    // Barramento de dados de saída (vai para o RDM)
);

    always @(*) begin
        if (Read) begin // A memória só responde se a UC mandar ler (Read = 1)
            case (entrada)
                //------------INSTRUÇOES---------
                8'h00: saida = 8'h20; // LDA (Carrega o valor de 0x80 no AC)
                8'h01: saida = 8'h80; // endereço 0x80
                
                8'h02: saida = 8'h60; // NOT (inverte os bits do AC)
                
                8'h03: saida = 8'h30; // ADD (Soma com o valor de 0x81)
                8'h04: saida = 8'h81; // endereço 0x81 (Contém o valor 1)
                
                8'h05: saida = 8'h30; // ADD (Soma com o valor de 0x82)
                8'h06: saida = 8'h82; // endereço 0x82
                
                8'h07: saida = 8'hA0; // JZ (Pula para 0x0D se Z=1)
                8'h08: saida = 8'h0D; // endereço de destino do pulo (0x0D)
                
                //Caso sejam DIFERENTES:
                8'h09: saida = 8'h20; // LDA
                8'h0A: saida = 8'h83; // endereço 0x83
                
                8'h0B: saida = 8'h80; // JMP
                8'h0C: saida = 8'h0F; // endereço de destino do pulo (0x0F)
                
                //Caso sejam IGUAIS:
                8'h0D: saida = 8'h20; // LDA
                8'h0E: saida = 8'h84; // endereço 0x84
                
                8'h0F: saida = 8'hF0; // HLT (para o processador)

                //----DADOS ----
                8'h80: saida = 8'h0A; // dado 1: Valor 10
                8'h81: saida = 8'h01; // dado 2: Valor 1 
                8'h82: saida = 8'h0A; // dado 3: Valor 10
                8'h83: saida = 8'h00; // constante Falso (0)
                8'h84: saida = 8'h01; // constante Verdadeiro (1)

                default: saida = 8'h00;
            endcase
        end else begin
            saida = 8'h00; // Se Read for 0, a saída fica zerada (ou 8'bzzzzzzzz se for barramento compartilhado)
        end
    end

endmodule