module flip_flop_d(input clk, rst, d,
									output reg q);
	always@(posedge clk or posedge rst)
	//--reset assíncrono-- (nao depende do clockl)
	//always@(posedge clk) --reset síncrono--
	
	
	begin
		if(rst == 1'b1)
			q <= 1'b0;
		else
			q <= d;
		
		
	end
	
endmodule
