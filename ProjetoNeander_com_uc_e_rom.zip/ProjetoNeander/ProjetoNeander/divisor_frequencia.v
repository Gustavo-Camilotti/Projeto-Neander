module divisor_frequencia(clk_50, rst, clk_saida);
	
		input wire clk_50;
		input wire rst;
		output wire clk_saida;
		
		wire [24:0] q;
		wire [24:0] d;
		
		genvar i;
		generate
			
			//primeira vez 
			assign d[0] = ~q[0];
			flip_flop_d FF0(clk_50, rst, d[0], q[0]);
			
			//resto
			for (i = 1; i < 25; i = i+1)
			begin : cadeia_div
				assign d[i] = ~q[i];
				flip_flop_d FFI (q[i-1], rst, d[i], q[i]);
			end 
		endgenerate
		
		assign clk_saida = ~q[24];
		

endmodule
