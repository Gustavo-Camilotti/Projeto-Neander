module memoria_rom(
    input  wire [7:0] entrada, //barramento de endereço (vem da saida do rem)
    output reg  [7:0] saida    //barramento de dados de saída (vai para a entrada do rdm)
);

    always @(*) begin
        case (entrada)
				//------------INSTRUÇOES---------
            //compara as posições 0x80 e 0x82. Carrega 1 no AC se forem iguais, 0 se diferentes.
            8'h00: saida = 8'h20; //LDA (Carrega o valor de 0x80 no AC)
            8'h01: saida = 8'h80; //endereço 0x80
            
            8'h02: saida = 8'h60; //NOT (inverte os bits do AC)
            
            8'h03: saida = 8'h30; //ADD (Soma com o valor de 0x81 -10+1)
            8'h04: saida = 8'h81; //endereço 0x81 (Contém o valor 1)
            
            8'h05: saida = 8'h30; //ADD (Soma com o valor de 0x82)
            8'h06: saida = 8'h82; //endereço 0x82
            
            8'h07: saida = 8'hA0; //JZ (Se o resultado deu zero, significa que eram iguais. Pula para 0x0D)
            8'h08: saida = 8'h0D; //endereço de destino do pulo (0x0D)
            
            //Caso sejam DIFERENTES (naoo pulou no JZ):
            8'h09: saida = 8'h20; //LDA (Carrega o valor de 0x83, que é 0)
            8'h0A: saida = 8'h83; //endereço 0x83
            
            8'h0B: saida = 8'h80; //JMP (Desvia para o fim do programa para evitar executar o bloco de igualdade)
            8'h0C: saida = 8'h0F; //endereço de destino do pulo (0x0F)
            
            //Caso sejam IGUAIS (vai JZ):
            8'h0D: saida = 8'h20; //LDA (Carrega o valor de 0x84, que é 1)
            8'h0E: saida = 8'h84; //endereço 0x84
            
            8'h0F: saida = 8'hF0; //HLT (para o processador)

            //----DADOS ----
            8'h80: saida = 8'h0A; //dado 1: Valor 10 (decimal)
            8'h81: saida = 8'h01; //dado 2: Valor 1  (decimal) usado para fazer a subtração via complemento
            8'h82: saida = 8'h0A; //dado 3: Valor 10 (decimal) para testar a igualdade (10 == 10)
            8'h83: saida = 8'h00; //constante Falso (0)
            8'h84: saida = 8'h01; //constante Verdadeiro (1)

            default: saida = 8'h00; //qualquer outra posição limpa a saída
        endcase
    end

endmodule
